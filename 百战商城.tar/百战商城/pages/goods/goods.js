
Page({

    /**
     * 页面的初始数据
     */
    data: {
        goodsData:[]
    },

    /**
     * 生命周期函数--监听页面加载
     * 在接收数据的时候进行数据的转化
     * goodsData:JSON.parse(options.goodsData)
     */
    onLoad(options) {
        this.setData({
            goodsData:JSON.parse(options.goodsData)
        })
    }
})